import com.opencsv.CSVReaderBuilder
import scala.jdk.CollectionConverters._

object Q3 {

  case class Flight(passengerId: String, from: String, to: String)

  def main(args: Array[String]): Unit = {
    val flightData = """C:\\Users\\feder\\OneDrive\\Desktop\\quantexa\\flightData.csv"""
    val passengerData = """C:\Users\feder\OneDrive\Desktop\quantexa\passengers.csv"""

    val longestRuns = findLongestRuns(flightData, passengerData)
    printLongestRuns(longestRuns)
  }

  def findLongestRuns(flightFilePath: String, passengerFilePath: String): Map[String, Int] = {
    val flightReader = new CSVReaderBuilder(new java.io.FileReader(flightFilePath)).withSkipLines(1).build()
    val passengerReader = new CSVReaderBuilder(new java.io.FileReader(passengerFilePath)).withSkipLines(1).build()

    val flightRows = flightReader.readAll().asScala.map(row => Flight(row(0), row(2), row(3))).toList
    val passengerRows = passengerReader.readAll().asScala.toList

    val passengerIdIndex = 0

    val runsByPassenger = flightRows
      .groupBy(_.passengerId)
      .view.mapValues { flights =>
        val nonUKRuns = getNonUKRuns(flights.map(_.to).distinct)
        if (nonUKRuns.nonEmpty) nonUKRuns.max else 0
      }
      .toMap

    runsByPassenger
  }

  def getNonUKRuns(countries: List[String]): List[Int] = {
    countries.foldLeft((0, 0)) { case ((currentRun, longestRun), country) =>
      if (country != "UK") (if (currentRun > 0) currentRun + 1 else 1, Math.max(longestRun, currentRun))
      else (0, longestRun)
    }._2 :: Nil
  }

  def printLongestRuns(longestRuns: Map[String, Int]): Unit = {
    printf("%-15s%-15s%n", "Passenger ID", "Longest Run")
    longestRuns.toList.sortBy { case (_, runLength) => -runLength }.foreach { case (passengerId, runLength) =>
      printf("%-15s%-15d%n", passengerId, runLength)
    }
  }
}
