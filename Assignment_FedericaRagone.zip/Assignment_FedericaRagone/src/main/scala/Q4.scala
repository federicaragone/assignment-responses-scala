import scala.collection.mutable

object Q4 {

  case class Flight(passengerId: String, flightId: Int)

  def main(args: Array[String]): Unit = {
    val filename = """C:\\Users\\feder\\OneDrive\\Desktop\\quantexa\\flightData.csv"""
    val flights: List[Flight] = readFlights(filename)

    val flightGroups: Map[Int, List[Flight]] = flights.groupBy(_.flightId)

    val combinations: mutable.Map[(String, String), Int] = mutable.Map().withDefaultValue(0)

    for {
      (_, group) <- flightGroups
      i <- group.indices
      j <- i + 1 until group.length
    } {
      val passenger1 = group(i).passengerId
      val passenger2 = group(j).passengerId
      combinations((passenger1, passenger2)) += 1
    }

    val filteredCombinations = combinations.filter(_._2 > 3)

    val sortedCombinations = filteredCombinations.toList.sortBy(-_._2)

    val maxP1Length = sortedCombinations.map(_._1._1.length).max
    val maxP2Length = sortedCombinations.map(_._1._2.length).max

    println(s"${"Passenger 1 ID".padTo(maxP1Length + 5, ' ')}${"Passenger 2 ID".padTo(maxP2Length + 5, ' ')}Number of flights together")
    sortedCombinations.foreach { case ((passenger1, passenger2), flightsTogether) =>
      println(f"${passenger1.padTo(maxP1Length + 5, ' ')}${passenger2.padTo(maxP2Length + 5, ' ')}$flightsTogether")
    }
  }

  def readFlights(filename: String): List[Flight] = {
    val bufferedSource = io.Source.fromFile(filename)
    val flights = bufferedSource.getLines().drop(1).map { line =>
      val cols = line.split(",").map(_.trim)
      Flight(cols(0), cols(1).toInt)
    }.toList
    bufferedSource.close()
    flights
  }
}
