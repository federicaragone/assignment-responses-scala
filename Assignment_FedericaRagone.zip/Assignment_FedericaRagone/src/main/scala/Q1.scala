import com.opencsv.CSVReaderBuilder
import java.time.LocalDate
import scala.jdk.CollectionConverters._

object Q1 {

  def main(args: Array[String]): Unit = {
    val flightData = """C:\\Users\\feder\\OneDrive\\Desktop\\quantexa\\flightData.csv"""
    val dateColumnName = "date"

    val flightsByMonth = readExcel(flightData, dateColumnName)
    printResults(flightsByMonth)
  }

  def readExcel(filePath: String, dateColumnName: String): Map[Int, Int] = {
    val reader = new CSVReaderBuilder(new java.io.FileReader(filePath)).withSkipLines(1).build()
    val rows = reader.readAll().asScala.toList

    val dateColumnIndex = rows.head.indexOf(dateColumnName) + 5
    val idColumnIndex = 1

    val flightsByMonth = rows
      .map(row => (getMonthFromDate(row(dateColumnIndex)), row(idColumnIndex)))
      .distinct
      .groupBy(_._1)
      .view.mapValues(_.size)
      .toMap

    (1 to 12).map(month => month -> flightsByMonth.getOrElse(month, 0)).toMap
  }

  def getMonthFromDate(dateStr: String): Int = {
    LocalDate.parse(dateStr).getMonthValue
  }

  def printResults(flightsByMonth: Map[Int, Int]): Unit = {
    printf("%-10s%-15s%n", "Month", "Total Flights")
    (1 to 12).foreach { month =>
      val count = flightsByMonth.getOrElse(month, 0)
      printf("%-10d%-15d%n", month, count)
    }
  }
}
