import com.opencsv.CSVReaderBuilder
import scala.jdk.CollectionConverters._

object Q2 {

  def main(args: Array[String]): Unit = {
    val flightData = "C:\\Users\\feder\\OneDrive\\Desktop\\quantexa\\flightData.csv"
    val passengerData = "C:\\Users\\feder\\OneDrive\\Desktop\\quantexa\\passengers.csv"
    val dateColumnName = "date"

    val topFrequentFlyers = findTopFrequentFlyers(flightData, passengerData, dateColumnName, 100)
    printFrequentFlyers(topFrequentFlyers)
  }

  def findTopFrequentFlyers(flightFilePath: String, passengerFilePath: String, dateColumnName: String, limit: Int): List[(String, Int, String, String)] = {
    val flightReader = new CSVReaderBuilder(new java.io.FileReader(flightFilePath)).withSkipLines(1).build()
    val passengerReader = new CSVReaderBuilder(new java.io.FileReader(passengerFilePath)).withSkipLines(1).build()

    val flightRows = flightReader.readAll().asScala.toList
    val passengerRows = passengerReader.readAll().asScala.toList

    val passengerIdIndex = 0

    val frequentFlyers = flightRows
      .groupBy(row => row(passengerIdIndex))
      .view.mapValues(_.size)
      .toList
      .sortBy { case (_, count) => -count }
      .take(limit)

    frequentFlyers.flatMap { case (passengerId, flightCount) =>
      val passengerInfo = passengerRows.find(row => row(passengerIdIndex) == passengerId)
      val (firstName, lastName) = passengerInfo.map(row => (row(1), row(2))).getOrElse(("Unknown", ""))
      List((passengerId, flightCount, firstName, lastName))
    }
  }

  def printFrequentFlyers(results: List[(String, Int, String, String)]): Unit = {
    printf("%-15s%-20s%-15s%-15s%n", "Passenger ID", "Number of Flights", "First name", "Last name")
    results.foreach { case (passengerId, flightCount, firstName, lastName) =>
      printf("%-15s%-20d%-15s%-15s%n", passengerId, flightCount, firstName, lastName)
    }
  }
}
